public class Main {
    public static void main(String[] args) {
// Create test array of numbers and print to screen
        int[] test1 = {99,34,50,65,23,78,91,82,86,50,21,29,44,36,49,50,55,58,98,91};
        int[] test2 = {99,34,50,65,23,78,91,82,86,50,21,29,44,36,49,50,55,58,98,91};
        printArray(test1);
// Sort new array and print sort stats
        bubbleSort(test1);
        printArray(test1);
        selectionSort(test2);
        printArray(test2);
// Search *sorted* array with both search algorithms
        System.out.println(binarySearch(test1, 50)); //index 9 for test array
        System.out.println(linearSearch(test1, 50)); // index 7 for test array
    }
    public static void printArray(int[] array) {
/*
Description: prints the contents of an array to screen one element per line
Parameters: int array of values to be printed
Returns: void
*/
        System.out.println("-----");
        for(int i = 0; i < array.length; i++){
            System.out.println( array[i] );
        }
    }
    public static void swap(int[] array, int posA, int posB)
    {int temp = array[posB];
        array[posB] = array[posA];
        array[posA] = temp;

    }
    public static void bubbleSort(int[] array) {
        for (int out = array.length-1; out > 0; out--) {
            for (int in = 0; in < out; in++) {
                if (array[in] > array[in+1]) {
                    int tmp = array[in];
                    array[in] = array[in+1];
                    array[in+1] = tmp;
                }
            }
        }
    }
    public static void selectionSort(int array[]) {
        int in, out, min;
        for (out=0; out < array.length-1; out++) {
            min = out;
            for (in = out+1; in < array.length; in++) {
                if (array[in] < array[min]) {
                    min = in;
                }
            }
            int tmp = array[out];
            array[out] = array[min];
            array[min] = tmp;
        }
    }
    public static int linearSearch(int array[], int key) {
        for(int i = 0; i < array.length; i++) {
            if (key == array[i]) {
                return i;
            }
        }
        return -1;
    }
    public static int binarySearch(int array[], int key) {
        selectionSort(array);
        int left = 0, right = array.length-1;
        while (left <= right) {
            int pivot = (left + right) / 2;
            if (key == array[pivot]) {
                return pivot;
            } else if (key > array[pivot]) {
                left = pivot + 1;
            } else {
                right = pivot - 1;
            }
        }
        return -1;
    }
}