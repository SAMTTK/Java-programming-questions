import static org.junit.Assert.*;
import org.junit.Test;
public class MainTest {
    @Test
    public void testSwap() {
        Main mn = new Main();
        int[] array1 = new int[]{1,2,3};
        int[] array2 = new int[]{-1,2,3,-4,-5};
        mn.swap(array1,0,2);
        assertArrayEquals(new int[]{3,2,1},array1);
        mn.swap(array2,0,3);
        assertArrayEquals(new int[]{-4,2,3,-1,-5},array2);
    }
    @Test
    public void testBinarySearch() {
        Main mn = new Main();
        int []a = {1,2,3,4,9};
        assertEquals(mn.binarySearch(a,3),2);
        assertEquals(mn.binarySearch(a,5),-1);
        int [] b = {-93590,-65986, -63178, -55022,-46538,-28121,-15371,-
                1495,7548,31892,39436,49102,57026,57026,57130,65941,79206,88663,94355};
        assertEquals(mn.binarySearch(b,-55022),3);
        int [] c = {-1,1,2,3,3,4,5,6,7,8};
        assertEquals(mn.binarySearch(c,3),4);
    }
    @Test
    public void testSelectionSort() {
        Main mn = new Main();
        int []a = {-1,7,5,2,3};
        int []b = {-1,2,3,5,7};
        mn.selectionSort(a);
        assertArrayEquals(a,b);
        int [] c = {94355,65941,57130,39436,-55022,79206,-63178,31892,-65986,57026,-
                93590,49102,-28121,-1495,7548,88663,-15371,-46538,57026};
        int [] d = {-93590,-65986, -63178, -55022,-46538,-28121,-15371,-
                1495,7548,31892,39436,49102,57026,57026,57130,65941,79206,88663,94355};
        mn.selectionSort(c);
        assertArrayEquals(c,d);
    }
    @Test
    public void testBubbleSort() {
        Main mn = new Main();
        int []a = {1,9,4,2,3};
        int []b = {1,2,3,4,9};
        mn.bubbleSort(a);
        assertArrayEquals(a,b);
        int [] c = {94355,65941,57130,39436,-55022,79206,-63178,31892,-65986,57026,-
                93590,49102,-28121,-1495,7548,88663,-15371,-46538,57026};
        int [] d = {-93590,-65986, -63178, -55022,-46538,-28121,-15371,-
                1495,7548,31892,39436,49102,57026,57026,57130,65941,79206,88663,94355};
        mn.bubbleSort(c);
        assertArrayEquals(c,d);
    }
    @Test
    public void testLinearSearch() {
        Main mn = new Main();
        int []a = {1,2,3,4,9};
        assertEquals(mn.linearSearch(a,9),4);
        assertEquals(mn.linearSearch(a,5),-1);
        int [] b = {-93590,-65986, -63178, -55022,-46538,-28121,-15371,-
                1495,7548,31892,39436,49102,57026,57026,57130,65941,79206,88663,94355};
        assertEquals(mn.linearSearch(b,57026),12);
        assertEquals(mn.linearSearch(b,45),-1);
        int [] c = {3,6,7,9,5};
        assertEquals(mn.linearSearch(c,5),4);
        assertEquals(mn.linearSearch(c,1),-1);
    }
}