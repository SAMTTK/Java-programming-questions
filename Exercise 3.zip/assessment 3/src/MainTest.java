import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
public class MainTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    @Test
    public void TestPrintArray() throws IOException{
        System.setOut(new PrintStream(outContent));
        Main mn = new Main();
        mn.PrintArray(new int[]{ 1, 2, 5});
        assertEquals("1\n2\n5\n", outContent.toString());
        System.setOut(originalOut);
    }
    @Test
    public void TestWriteLineToFile() throws IOException{
        Main mn = new Main();
        File file = File.createTempFile("temp1", ".tmp");
        try (BufferedReader br = new BufferedReader(new FileReader(file))){
            mn.WriteLineToFile(file.getAbsolutePath(), "Skoda");
            assertEquals("Skoda", br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void TestReadLineFromFile() throws IOException{
        Main mn = new Main();
        File file = File.createTempFile("temp", ".tmp");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))){
            bw.write("BMW");
            bw.write(System.lineSeparator()); // new line
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertEquals("BMW", mn.ReadLineFromFile(file.getAbsolutePath()));
    }
    @Test
    public void TestWriteArrayToFile() throws IOException{
        Main mn = new Main();
        File file = File.createTempFile("temp", ".tmp");
        int[] test = new int[]{10,20,30};
        int[] tmp = new int[3];
        mn.WriteArrayToFile(file.getAbsolutePath(), test);
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int c = 0;
            while ((line = br.readLine()) != null) {
                tmp[c]=Integer.parseInt(line);
                c++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertArrayEquals(tmp, test);
    }
    @Test
    public void TestReadArrayFromFile() throws IOException{
        Main mn = new Main();
        int[] temp = {23,45,67,91,23};
        File file = File.createTempFile("temp", ".tmp");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))){
            for(int x=0; x<5; x++){
                bw.write(String.valueOf(temp[x]));
                bw.write(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertArrayEquals(temp,mn.ReadArrayFromFile(file.getAbsolutePath()));
    }
}