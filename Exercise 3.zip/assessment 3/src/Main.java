import uulib.InputFile;
import java.util.*;
import java.io.*;
public class Main {
    public static void main(String[] args) {
        String path = System.getProperty("user.dir") + "/data2.txt";
        boolean m = true;
        int[] array = RandomGenSequence(5, 1234567);
        PrintArray(array);
        WriteLineToFile("C:/Users/Admin'/Documents/FileIO test.txt", "Dermot3");
        System.out.println(ReadLineFromFile("C:/Users/Admin'/Documents/FileIO test.txt"));
        WriteArrayToFile("C:/Users/Admin'/Documents/write test.txt", array);
        int[] array2 = ReadArrayFromFile("C:/Users/Admin'/Documents/read test.txt");
        PrintArray(array2);
    }

    public static int[] RandomGenSequence(int length, int seed) {
        Random random = new Random(seed); // Seed is set to 12345
        int[] array = new int[length];
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(100); // Random integers from 0 to 99
        }
        return array;
    }

    public static void PrintArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }

    public static void WriteLineToFile(String path, String data) {
        try {
            FileWriter fw = new FileWriter(path);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(data);
            pw.close();
            bw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public static String ReadLineFromFile(String path) {
        InputFile a = new InputFile(path);
        String b = "";
        while(!a.eof()){
            b+=a.readString();
        }
        return b;
    }

    public static void WriteArrayToFile(String path, int[] array) {
        try {
            FileWriter fw = new FileWriter(path);
            PrintWriter pw = new PrintWriter(fw);
            for (int i = 0; i < array.length; i++) {
                pw.println(array[i]);
            }
            pw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public static int[] ReadArrayFromFile(String path) {
        InputFile a = new InputFile(path);
        int e = 0;
        while (!a.eof()) {
            while(a.readInt()!=-0){
                e+=1;
            }
        }
        int[] b = new int[e];
        a.close();
        InputFile c = new InputFile(path);
        while (!c.eof()) {
            for (int i = 0; i < b.length ; i++) {
                b[i] = c.readInt();
            }
        }
        a.close();
        return b;
    }
}