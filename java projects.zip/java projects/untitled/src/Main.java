import java.util.StringTokenizer;
public class Main {
    int balance = 0;
    public static void main(String args[]) {
    int b= 3;
    insertMoney(30);
    }
    public static void insertMoney(int amount) {
        if (amount > 0) {
            balance += amount;
        } else {
            System.out.println("Use a positive amount: " + amount);
        }
    }
}