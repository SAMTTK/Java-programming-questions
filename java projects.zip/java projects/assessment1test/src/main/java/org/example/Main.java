


public class Main {
    public static void main(String[] args) {
// Create some example arrays
        int[][] array = new int[][]{{1, 8, 3}, {-7, 5, 2}, {4, 0, 2}};
        int[][] rowmagic = new int[][]{{1, 2, 3}, {-1, 5, 2}, {4, 0, 2}};
        int[][] colmagic = new int[][]{{1, -1, 4, 10}, {3, 5, 0, -6}};
// Print max and min
        System.out.println("Array max = " + array2DMax(array));
        System.out.println("Array min = " + array2DMin(array));
// Print row 0 sum and column 2 sum from arr2d.
        System.out.println("\nRow 0 sum = " + rowSum(array, 0));
        System.out.println("Col 2 sum = " + colSum(array, 2));
// Get all row sums and all col sums and print
        int[] rowsum = allRowSums(array);
        int[] colsum = allColSums(array);
        System.out.print("\nAll rows sums = [");
        for (int i = 0; i < rowsum.length; i++) {
            System.out.print(rowsum[i] + " ");
        }
        System.out.print("]\n");
        System.out.print("All cols sums = [");
        for (int i = 0; i < colsum.length; i++) {
            System.out.print(colsum[i] + " ");
        }
        System.out.print("]\n");
// Test row magic and col magic arrays
        System.out.println("\nCheck row magic array");
        System.out.println("Row magic = " + isRowMagic(rowmagic));
        System.out.println("Col magic = " + isColMagic(rowmagic));
        System.out.println("\nCheck col magic array");
        System.out.println("Row magic = " + isRowMagic(colmagic));
        System.out.println("Col magic = " + isColMagic(colmagic));
    }
    public static int array2DMax(int[][] a){
        int max = a[0][0];
        for(int i = 0; i<a.length; i++){
            for(int j = 0; j<a[i].length; j++){
                if (a[i][j] > max){
                    max = a[i][j];
                }
            }
        }
        return max;
    }
    public static int array2DMin(int[][] a){
        int min = a[0][0];
        for(int i = 0; i<a.length; i++){
            for(int j = 0; j<a[i].length; j++){
                if (a[i][j] < min){
                    min = a[i][j];
                }
            }
        }
        return min;
    }
    public static int rowSum(int[][] a, int x) {
        int t = 0;
        for (int i = 0; i < a[x].length; i++) {
            t += a[x][i];
        }
        return t;
    }

    public static int colSum(int[][] a, int x) {
        int t = 0;
        for (int i = 0; i < a.length; i++) {
            t += a[i][x];
        }
        return t;
    }

    public static int[] allRowSums(int[][] a) {
        int[] sums = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            sums[i] = rowSum(a, i);}
        return sums;
    }
    public static int[] allColSums ( int[][] a){
        int[] sums = new int[a[0].length];
        for(int i = 0; i < a.length; i++){
            for (int j = 0; j < a[i].length; j++) {
                sums[j] = colSum(a, j);}}
        return sums;
    }

    public static boolean isRowMagic ( int[][] a){
        boolean is = true;
        for(int i = 1; i < a.length; i++){
            if (rowSum(a,i-1) != rowSum(a,i)){
                is = false;
            }
        }
        return is; // return your own value here
    }
    public static boolean isColMagic ( int[][] a){
        boolean is = true;
        for(int i = 1; i < a[0].length; i++){
            if (colSum(a,i-1) != colSum(a,i)){
                is = false;
            }
        }
        return is; // return your own value here
    }
}


