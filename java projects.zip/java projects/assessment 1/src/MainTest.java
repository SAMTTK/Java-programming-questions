import static org.junit.Assert.*;
import org.junit.Test;
public class MainTest {
    @Test
    public void testIsRowMagic() {
        Main mn = new Main();
        int[][] rowmagic ={{1,2,5,4},{-1,10,2,1},{5,6,2,-1}};
        int[][] colmagic ={{1,-1,4,10},{3,5,0,-6}};
        assertTrue(mn.isRowMagic(rowmagic));
        assertFalse(mn.isRowMagic(colmagic));
    }
    @Test
    public void testAllColSum() {
        Main mn = new Main();
        int[][] test1 = {{-10},{-5},{-2}};
        int[][] test2 = {{10,5,2}};
        int[][] test3 = {{1,2,13,1},{-1,1,2,1},{4,9,2,1}};
        assertArrayEquals(mn.allColSums(test1),new int[]{-17});
        assertArrayEquals(mn.allColSums(test2),new int[]{10,5,2});
        assertArrayEquals(mn.allColSums(test3),new int[]{4,12,17,3});
    }
    @Test
    public void testAllRowSum() {
        Main mn = new Main();
        int[][] test1 = {{-10},{-5},{-2}};
        int[][] test2 = {{10,5,2}};
        int[][] test3 = {{1,2,13,1},{-1,1,2,1},{4,9,2,1}};
        assertArrayEquals(mn.allRowSums(test1),new int[]{-10,-5,-2});
        assertArrayEquals(mn.allRowSums(test2),new int[]{17});
        assertArrayEquals(mn.allRowSums(test3),new int[]{17,3,16});
    }
    @Test
    public void testColSum() {
        Main mn = new Main();
        int [][]test1 = {{1,3,6,8},{2,6,9,-1},{4,5,3,7}};
        int [][]test2 = {{-10},{-8},{-3}};
        int [][]test3 = {{100,120,150}};
        assertEquals(mn.colSum(test1,1),14);
        assertEquals(mn.colSum(test2,0),-21);
        assertEquals(mn.colSum(test3,2),150);
    }
    @Test
    public void testRowSum() {
        Main mn = new Main();
        int [][]test1 = {{1,3,6,8},{2,6,9,-1},{4,5,3,7}};
        int [][]test2 = {{-10},{-8},{-3}};
        int [][]test3 = {{100,120,150}};
        assertEquals(mn.rowSum(test1,1),16);
        assertEquals(mn.rowSum(test2,2),-3);
        assertEquals(mn.rowSum(test3,0),370);
    }
}