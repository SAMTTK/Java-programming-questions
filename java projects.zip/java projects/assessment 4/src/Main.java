public class Main {
    public static void main(String[] args) {
        Product product1 = new Product("SN123456", 10, 2899.95);
        product1.printProduct();
        Product product2 = new Product("SN123459");
        product2.printProduct();
        Product product3 = new Product();
        product3.setSku("SN123463");
        product3.setQuantity(5);
        product3.setPrice(3699.95);
        System.out.println(product3.productToString());
    }
}

