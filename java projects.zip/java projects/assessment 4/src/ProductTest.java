import static org.junit.Assert.*;
import org.junit.Test;
public class ProductTest {
    @Test
    public void testDefaultConstructor(){
        Product p1= new Product();
        assertTrue(p1.sku.equals(""));
        assertEquals(p1.quantity,0);
        assertEquals(p1.price,0, 0.001);
    }
    @Test
    public void testPartialConstructor(){
        Product p1= new Product("SN123463");
        assertTrue(p1.sku.equals("SN123463"));
        assertEquals(p1.quantity,0);
        assertEquals(p1.price,0.0, 0.001);
    }
    @Test
    public void testFullConstructor(){
        Product p1= new Product("SN123463",5,3699.95);
        assertTrue(p1.sku.equals("SN123463"));
        assertEquals(p1.quantity,5);
        assertEquals(p1.price,3699.95, 0.001);
    }
    @Test
    public void testGetters(){
        Product p1= new Product("SN123463",5,3699.95);
        assertTrue(p1.getSku().equals("SN123463"));
        assertEquals(p1.getQuantity(),5);
        assertEquals(p1.getPrice(),3699.95, 0.001);
    }
    @Test
    public void testSetters(){
        Product p1= new Product();
        p1.setSku("SN123463");
        p1.setQuantity(5);
        p1.setPrice(3699.95);
        assertTrue(p1.sku.equals("SN123463"));
        assertEquals(p1.quantity,5);
        assertEquals(p1.price,3699.95, 0.001);
    }
}