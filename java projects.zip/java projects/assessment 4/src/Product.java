public class Product {
    double price;
    int quantity;
    String sku;

    public Product() {
        sku = "";
        quantity = 0;
        price = 0;
    }

    public Product(String ske) {
        sku = ske;
    }

    public Product(String a, int b, double c) {
        sku = a;
        quantity = b;
        price = c;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public void printProduct(){
        System.out.println("price = "+price+"\nquantity = "+quantity+"\nsku = "+sku);
    }

    public String productToString(){
        return("price = "+price+"\nquantity = "+quantity+"\nsku = "+sku);
    }

    public void setSku(String ska){
        sku = ska;
    }

    public void setQuantity(int q) {
        quantity = q;
    }

    public void setPrice(double p){
        price = p;
    }
}