//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        double b = Math.pow(2,0);
        double a = -Math.pow(2,32);
    for(double i = 31; i>8; i-=1){
        a+= Math.pow(2,i);
    }
        for(double i = 4; i>-1; i-=1){
            a+= Math.pow(2,i);
        }
    System.out.println(a);
        System.out.println(b);
    }
}